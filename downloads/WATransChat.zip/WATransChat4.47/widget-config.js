// 注意：扩展页面 CSP 禁止内联脚本，所以把配置放到独立文件中再通过 <script src> 引入。
// 这里提供 widget.js 需要的全局配置。
window.CHAT_WIDGET_API = 'https://chat.babyamy.store/api';
window.CHAT_WIDGET_WS = 'wss://chat.babyamy.store/ws';

